from tkinter import *
from tkinter.ttk import Combobox, Treeview
from tkinter import messagebox
from Updatepass import UpdateClass
from printpage import printClass
import pymysql
class ManangePassengersClass:
    def __init__(self,abc):
        self.window = abc
        self.f1 = Frame(self.window, background="#F6F681")
        self.f1.place(x=0, y=0, width=1350, height=700)

        from PIL import Image, ImageTk
        self.bkimg1 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg1 = ImageTk.PhotoImage(self.bkimg1)
        self.bklbl = Label(self.f1, image=self.bkphotoimg1)
        self.bklbl.place(x=0, y=0)

        self.headlbl = Label(self.f1, text="Manage Passengers", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=1350, height=70)

        self.mytable = Treeview(self.f1, columns=['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10', 'c11'])

        self.mytable.heading('c1', text='ID')
        self.mytable.heading('c2', text='Name')
        self.mytable.heading('c3', text='Age')
        self.mytable.heading('c4', text='Gender')
        self.mytable.heading('c5', text='Email')
        self.mytable.heading('c6', text='Bus Name')
        self.mytable.heading('c7', text='Bus Type')
        self.mytable.heading('c8', text='Route')
        self.mytable.heading('c9', text='Date')
        self.mytable.heading('c10', text='Arr/Dept')
        self.mytable.heading('c11', text='Price')

        self.mytable['show'] = 'headings'

        self.mytable.column('c1', width=50, anchor='center')
        self.mytable.column('c2', width=150, anchor='w')
        self.mytable.column('c3', width=50, anchor='center')
        self.mytable.column('c4', width=80, anchor='center')
        self.mytable.column('c5', width=200, anchor='center')
        self.mytable.column('c6', width=120, anchor='center')
        self.mytable.column('c7', width=150, anchor='center')
        self.mytable.column('c8', width=100, anchor='center')
        self.mytable.column('c9', width=100, anchor='center')
        self.mytable.column('c10', width=100, anchor='center')
        self.mytable.column('c11', width=80, anchor='center')

        self.mytable.place(x=80, y=200)

        self.b2 = Button(self.f1, text="Update/Delete Ticket",background='#7FDDF0', font=('Helvetica', 15), command=self.show5)
        self.b2.place(x=300, y=500, height=35, width=250)
        self.b3 = Button(self.f1, text="Print Ticket",background='#7FDDF0', font=('Helvetica', 15), command=lambda : printClass())
        self.b3.place(x=700, y=500, height=35, width=200)

        self.L4 = Label(self.f1, text="Filter by Bus Number", font=('Book Antiqua', 16, 'bold'), background="white")
        self.L4.place(x=55, y=120)
        self.v1 = StringVar()
        self.c1 = Combobox(self.f1, values=[""], textvariable=self.v1, state='readonly')
        self.c1.place(x=300, y=120, width=160, height=40)
        self.c1.bind("<<ComboboxSelected>>", lambda e: self.getbdata())

        self.makeDatabaseConnection()
        self.getAllData()
        self.filterb()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)

    def getAllData(self):
        try: ##pid	pname	age	gender	cnum	email	bname	btype	rname	date	arde	price
            qry = "select pid,pname,age,gender,email,bname,btype,rname,date,arde,price from passengerss "
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata=[]
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
                    r1 = [myrow[0],myrow[1],myrow[2],myrow[3],myrow[4],myrow[5],myrow[6],myrow[7],myrow[8],myrow[9],myrow[10]]
                    self.pdata.append(r1)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

    def show5(self):
        self.f1.destroy()
        self.f1 = Frame(self.window, background="red")
        self.f1.place(x=0, y=0, width=1350, height=700)
        UpdateClass(self.f1)

    def filterb(self):
        try:
            qry ="select distinct bnum from buses"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata = []
            if data:
                self.c1.set("Choose Bus Number")
                for myrow in data:
                    self.pdata.append(myrow[0])
            else:
                self.c1.set("No Bus")
            self.c1.config(values=self.pdata)

        except EXCEPTION as e:
            messagebox.showerror("Query Error","Error while fetching data :\n"+ str(e),parent=self.window)

    def getbdata(self):
        self.mytable.delete(*self.mytable.get_children())
        try:
            qry = "select pid,pname,age,gender,email,bname,btype,rname,date,arde,price from passengerss where bnum like %s"
            rowcount = self.curr.execute(qry, (self.v1.get()))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

if __name__ == '__main__':
    dummyHomepage = Tk()
    ManangePassengersClass(dummyHomepage)
    dummyHomepage.mainloop()
