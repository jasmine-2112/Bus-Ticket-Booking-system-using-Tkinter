from tkinter import *
from tkinter.ttk import Combobox, Treeview
from tkinter import messagebox
import pymysql
class BusDetailsClass:
    def __init__(self,myframe):
        self.window = myframe

        #----------Main Frame---------
        self.f1 = Frame(self.window)
        self.f1.place(x=0, y=0, width=1350, height=700)

        #----------Background Image----------
        from PIL import Image, ImageTk
        self.bkimg2 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.f1, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        # ----------Title----------
        self.headlbl = Label(self.f1, text="Buses Details", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=1320, height=70)

        # ----------Button Frame----------
        self.f2 = Frame(self.window,background="white")
        self.f2.place(x=20, y=120, width=200, height=380)
        self.L1 = Label(self.f2, text="Filter", font=('Book Antiqua', 20, 'bold'), background="#7FDDF0")
        self.L1.place(x=10, y=10, width=180, height=50)

        self.L2 = Label(self.f2, text="By Route", font=('Book Antiqua', 16, 'bold'), background="white")
        self.L2.place(x=50, y=80)
        self.v1 = StringVar()
        self.c1 = Combobox(self.f2, values=[""], textvariable=self.v1, state='readonly')
        self.c1.place(x=20, y=120, width=160, height=40)
        self.c1.bind("<<ComboboxSelected>>", lambda e: self.getroutedata())

        self.L3 = Label(self.f2, text="By Bus Name", font=('Book Antiqua', 16, 'bold'), background="white")
        self.L3.place(x=30, y=180)
        self.v2 = StringVar()
        self.c2 = Combobox(self.f2, values=[""], textvariable=self.v2, state='readonly')
        self.c2.place(x=20, y=220, width=160, height=40)
        self.c2.bind("<<ComboboxSelected>>", lambda e: self.getnamedata())

        self.L4 = Label(self.f2, text="By Date", font=('Book Antiqua', 16, 'bold'), background="white")
        self.L4.place(x=55, y=280)
        self.v3 = StringVar()
        self.c3 = Combobox(self.f2, values=[""], textvariable=self.v3, state='readonly')
        self.c3.place(x=20, y=320, width=160, height=40)
        self.c3.bind("<<ComboboxSelected>>", lambda e: self.getdatedata())

        # ----------Table----------
        self.mytable = Treeview(self.f1, columns=['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'], height=20)
        self.mytable.heading('c1', text='Bus Number')
        self.mytable.heading('c2', text='Bus Name')
        self.mytable.heading('c3', text='Bus Type')
        self.mytable.heading('c4', text='Route')
        self.mytable.heading('c5', text='Date')
        self.mytable.heading('c6', text='Arrival/departure')
        self.mytable.heading('c7', text='Duration')
        self.mytable.heading('c8', text='Price')

        self.mytable['show'] = 'headings'

        self.mytable.column('c1', width=100, anchor='n')
        self.mytable.column('c2', width=150, anchor='w')
        self.mytable.column('c3', width=150, anchor='center')
        self.mytable.column('c4', width=150, anchor='center')
        self.mytable.column('c5', width=100, anchor='center')
        self.mytable.column('c6', width=150, anchor='center')
        self.mytable.column('c7', width=100, anchor='center')
        self.mytable.column('c8', width=100, anchor='center')
        self.mytable.place(x=280, y=100)

        self.makeDatabaseConnection()
        self.getAllData()
        self.filterbusname()
        self.filterroute()
        self.filterdate()
        self.window.mainloop()
    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)

    def getAllData(self):
        try:
            qry = "select * from buses "
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata=[]
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
                    r1 = [myrow[0],myrow[1],myrow[2],myrow[3],myrow[4],myrow[5],myrow[6],myrow[7]]
                    self.pdata.append(r1)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

    def filterbusname(self):
        try:
            qry ="select distinct bname from buses"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata = []
            if data:
                self.c2.set("Choose Bus Name")
                for myrow in data:
                    self.pdata.append(myrow[0])
            else:
                self.c2.set("No bus name")
            self.c2.config(values=self.pdata)

        except EXCEPTION as e:
            messagebox.showerror("Query Error","Error while fetching data :\n"+ str(e),parent=self.window)

    def getnamedata(self):
        self.mytable.delete(*self.mytable.get_children())
        try:
            qry = "select * from buses where bname like %s"
            rowcount = self.curr.execute(qry, (self.v2.get()))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

    def filterroute(self):
        try:
            qry ="select distinct rname from buses"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata = []
            if data:
                self.c1.set("Choose Route")
                for myrow in data:
                    self.pdata.append(myrow[0])
            else:
                self.c1.set("No Route")
            self.c1.config(values=self.pdata)

        except EXCEPTION as e:
            messagebox.showerror("Query Error","Error while fetching data :\n"+ str(e),parent=self.window)

    def getroutedata(self):
        self.mytable.delete(*self.mytable.get_children())
        try:
            qry = "select * from buses where rname like %s"
            rowcount = self.curr.execute(qry, (self.v1.get()))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

    def filterdate(self):
        try:
            qry ="select distinct date from buses"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.pdata = []
            if data:
                self.c3.set("Choose Date")
                for myrow in data:
                    self.pdata.append(myrow[0])
            else:
                self.c3.set("No Route")
            self.c3.config(values=self.pdata)

        except EXCEPTION as e:
            messagebox.showerror("Query Error","Error while fetching data :\n"+ str(e),parent=self.window)

    def getdatedata(self):
        self.mytable.delete(*self.mytable.get_children())
        try:
            qry = "select * from buses where date like %s"
            rowcount = self.curr.execute(qry, (self.v3.get()))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)
            else:
                messagebox.showerror("Empty ", "No record Found",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n"+str(e),parent=self.window)

if __name__ == '__main__':
    dummyhomepage = Tk()
    BusDetailsClass(dummyhomepage)
    dummyhomepage.mainloop()
