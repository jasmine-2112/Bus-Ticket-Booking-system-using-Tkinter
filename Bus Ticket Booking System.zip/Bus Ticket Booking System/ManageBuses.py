from tkinter import *
from tkinter.ttk import Combobox, Treeview
from tkinter import messagebox
import pymysql
from tkcalendar import DateEntry
class ManageBusesClass:
    def __init__(self,myframe):
        self.window = myframe
        # ----------Background Image----------
        from PIL import Image, ImageTk
        self.bkimg2 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.window, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Manage Buses",font=('Book Antiqua',26,'bold'),
                             background="#7FDDF0",relief='groove',borderwidth=5)
        self.headlbl.place(x=0, y=0, width=1320, height=70)

        self.L1 = Label(self.window, text="Bus Number",font=myfont,background=mycolor1)
        self.L1.place(x=30, y=90, width=180, height=30)
        self.t1 = Entry(self.window, font=myfont)
        self.t1.place(x=220, y=90, width=180, height=30)

        self.L2 = Label(self.window, text="Bus Name",font=myfont,background=mycolor1)
        self.L2.place(x=30, y=140, width=180, height=30)
        self.t2 = Entry(self.window, font=myfont)
        self.t2.place(x=220, y=140, width=180, height=30)

        self.L3 = Label(self.window, text="Bus Type",font=myfont,background=mycolor1)
        self.L3.place(x=30, y=190, width=180, height=30)
        self.t3 = Entry(self.window, font=myfont)
        self.t3.place(x=220, y=190, width=180, height=30)

        self.L4 = Label(self.window, text="Route",font=myfont,background=mycolor1)
        self.L4.place(x=30, y=240, width=180, height=30)
        self.v1 = StringVar()
        self.c1 = Combobox(self.window, values=[""], textvariable=self.v1, state='readonly',font=myfont)
        self.c1.place(x=220, y=240, width=180, height=30)

        self.L5 = Label(self.window, text="Date", font=myfont, background=mycolor1)
        self.L5.place(x=430, y=90, width=180, height=30)
        self.t4 = DateEntry(self.window, font=("Calibri", 16), background='blue', year=2023, date_pattern='y-mm-dd')
        self.t4.place(x=620, y=90, width=180, height=30)

        self.L6 = Label(self.window, text="Arrival/Departure", font=myfont, background=mycolor1)
        self.L6.place(x=430, y=140, width=180, height=30)
        self.t5 = Entry(self.window, font=myfont)
        self.t5.place(x=620, y=140, width=180, height=30)

        self.L7 = Label(self.window, text="Duration", font=myfont, background=mycolor1)
        self.L7.place(x=430, y=190, width=180, height=30)
        self.t6 = Entry(self.window, font=myfont)
        self.t6.place(x=620, y=190, width=180, height=30)

        self.L8 = Label(self.window, text="Ticket Price", font=myfont, background=mycolor1)
        self.L8.place(x=430, y=240, width=180, height=30)
        self.t7 = Entry(self.window, font=myfont)
        self.t7.place(x=620, y=240, width=180, height=30)

        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Save Details",background=mycolor2,font=myfont, command=self.saveData)
        self.b1.place(x=900, y=110, width=130, height=30)
        self.b6 = Button(self.window, text="Clear Page", background=mycolor2, font=myfont, command=self.clearPage)
        self.b6.place(x=1050, y=110, width=130, height=30)
        self.b2 = Button(self.window,text="Update",background=mycolor2,font=myfont, command=self.updateData)
        self.b2.place(x=900, y=160, width=130, height=30)
        self.b3 = Button(self.window,text="Delete",background=mycolor2,font=myfont, command=self.deleteData)
        self.b3.place(x=1050, y=160, width=130, height=30)
        self.b4 = Button(self.window,text="Fetch",background=mycolor2,font=myfont, command=self.fetchData)
        self.b4.place(x=900, y=210, width=130, height=30)
        self.b5 = Button(self.window,text="Search",background=mycolor2,font=myfont, command=self.getAllData)
        self.b5.place(x=1050, y=210, width=130, height=30)
        self.t8 = Label(self.window, font=myfont ,background=mycolor2)
        self.t8.place(x=900, y=250, width=280, height=50)
        self.b4.bind('<Enter>', lambda e: self.message())
        self.b4.bind('<Leave>', lambda e: self.message1())
        self.b5.bind('<Enter>', lambda e: self.message2())
        self.b5.bind('<Leave>', lambda e: self.message1())


        #-------------Table-------------------
        self.mytable = Treeview(self.window, columns=['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'], height=15)
        self.mytable.heading('c1', text='Bus Number')
        self.mytable.heading('c2', text='Bus Name')
        self.mytable.heading('c3', text='Bus Type')
        self.mytable.heading('c4', text='Route')
        self.mytable.heading('c5', text='Date')
        self.mytable.heading('c6', text='Arrival/departure')
        self.mytable.heading('c7', text='Duration')
        self.mytable.heading('c8', text='Ticket Price')

        self.mytable['show'] = 'headings'

        self.mytable.column('c1', width=100, anchor='center')
        self.mytable.column('c2', width=150, anchor='w')
        self.mytable.column('c3', width=150, anchor='center')
        self.mytable.column('c4', width=150, anchor='center')
        self.mytable.column('c5', width=100, anchor='center')
        self.mytable.column('c6', width=150, anchor='center')
        self.mytable.column('c7', width=100, anchor='center')
        self.mytable.column('c8', width=100, anchor='center')
        self.mytable.place(x=150, y=320)

        self.makeDatabaseConnection()
        self.clearPage()
        self.getAllRoutes()
        self.window.mainloop()

    def message(self):
        self.t8.config(text='Fetch bus details by \nentering Bus number')

    def message2(self):
        self.t8.config(text='Search bus details by \nentering Bus number')
    def message1(self):
        self.t8.config(text="")

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost', db='bus', user="root", password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ", "Error database connection :\n" + str(e), parent=self.window)

    def saveData(self):
        if self.validate_check2() == False:
            return

        try:#bnum	bname	btype	rname	date	arde	duration	price
            qry = "insert into buses values(%s,%s,%s,%s,%s,%s,%s,%s)"
            rowcount = self.curr.execute(qry, (self.t1.get(), self.t2.get(), self.t3.get(), self.v1.get(),
                                               self.t4.get(), self.t5.get(), self.t6.get(), self.t7.get()))
            self.conn.commit()
            if rowcount == 1:
                messagebox.showinfo("Success", "Bus Details Added Successfully", parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def updateData(self):
        if self.validate_check2() == False:
            return

        try:
            qry = "update buses set bname=%s, btype=%s, rname=%s, date=%s, arde=%s, duration=%s, price=%s where bnum=%s"
            rowcount = self.curr.execute(qry, (self.t2.get(), self.t3.get(),
                                               self.v1.get(), self.t4.get(), self.t5.get(), self.t6.get(), self.t7.get(),self.t1.get()))
            self.conn.commit()
            if rowcount == 1:
                messagebox.showinfo("Success", "Bus Details Updated Successfully", parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while updating data :\n" + str(e), parent=self.window)

    def deleteData(self):
        ans = messagebox.askquestion("Confirmation", "Are you sure to delete ?", parent=self.window)
        if ans == "yes":
            try:
                qry = "delete from buses where bnum=%s"
                rowcount = self.curr.execute(qry, (self.t1.get()))
                self.conn.commit()
                if rowcount == 1:
                    messagebox.showinfo("Success", "Bus Details deleted Successfully", parent=self.window)
                    self.clearPage()
            except Exception as e:
                messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def getSelectedRow(self):
        rowid = self.mytable.focus()
        rowitem = self.mytable.item(rowid)
        rowdata = rowitem['values']
        pkcol = rowdata[0]
        self.fetchData(pkcol)

    def fetchData(self, pkcolumn=None):
        if pkcolumn == None:
            pk = self.t1.get()
        else:
            pk = pkcolumn
        try:
            qry = "select * from buses where bnum=%s"
            rowcount = self.curr.execute(qry, (pk))
            data = self.curr.fetchone()
            self.clearPage()
            if data:
                self.t1.insert(0, data[0])
                self.t2.insert(0, data[1])
                self.t3.insert(0, data[2])
                self.v1.set(data[3])
                self.t4.insert(0, data[4])
                self.t5.insert(0, data[5])
                self.t6.insert(0, data[6])
                self.t7.insert(0, data[7])

                self.b2['state'] = "normal"
                self.b3['state'] = "normal"
            else:
                messagebox.showwarning("Empty ", "No record Found", parent=self.window)


        except Exception as e:
            messagebox.showerror("Query Error ", "Error while fetching data :\n" + str(e), parent=self.window)

    def clearPage(self):
        self.t1.delete(0, END)
        self.t2.delete(0, END)
        self.t3.delete(0, END)
        self.c1.set("Choose Route")
        self.t4.delete(0, END)
        self.t5.delete(0, END)
        self.t6.delete(0, END)
        self.t7.delete(0, END)

        self.b2['state'] = "disable"
        self.b3['state'] = "disable"
        self.getAllData()

    def getAllData(self):
        try:
            self.mytable.delete(*self.mytable.get_children())
            qry = "select * from buses where bnum like %s"
            rowcount = self.curr.execute(qry, (self.t1.get() + "%"))
            data = self.curr.fetchall()
            self.pdata = []
            if data:
                for myrow in data:
                    self.mytable.insert("", END, values=myrow)
            else:
                messagebox.showwarning("Empty ", "No record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while fetching data :\n" + str(e), parent=self.window)

    def getAllRoutes(self):
        try:
            qry = "select * from routes"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.rouList = []
            if data:
                self.c1.set("Choose Route")
                for myrow in data:
                    self.rouList.append(myrow)
            else:
                self.c1.set("No Route")
            self.c1.config(values=self.rouList)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def validate_check2(self):
        if len(self.t1.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid Bus ID", parent=self.window)
            return False
        elif len(self.t2.get()) < 2:
            messagebox.showwarning("Validation Check", "Enter Bus name", parent=self.window)
            return False
        elif len(self.t3.get()) < 2:
            messagebox.showwarning("Validation Check", "Enter Bus Type", parent=self.window)
            return False
        elif (self.v1.get() == "Choose Route"):
            messagebox.showwarning("Validation Check", "Enter route", parent=self.window)
            return False
        elif (self.t4.get() == ""):
            messagebox.showwarning("Validation Check", "Invalid Date", parent=self.window)
            return False
        elif len(self.t5.get()) < 11 or '-' not in self.t5.get():
            messagebox.showwarning("Input Error", "Please valid arrival/departure time in (00:00-00:00) ", parent=self.window)
            return False
        elif 'h' not in self.t6.get() or 'min' not in self.t6.get() or len(self.t6.get()) < 9:
            messagebox.showwarning("Input Error", "Please valid duration time(00h 00min) ", parent=self.window)
            return False
        elif 'Rs.' not in self.t7.get() or len(self.t7.get()) < 4:
            messagebox.showwarning("Input Error", "Please valid ticket price ", parent=self.window)
            return False
        return True


if __name__ == '__main__':
    dummyHomepage = Tk()
    ManageBusesClass(dummyHomepage)
    dummyHomepage.mainloop()