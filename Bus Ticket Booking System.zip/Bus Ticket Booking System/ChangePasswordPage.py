from tkinter import *
from tkinter import messagebox
from PIL import Image,ImageTk
import pymysql
class ChangePasswordClass:
    def __init__(self,myframe,un,):
        self.window = myframe
        self.uname = un
        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'

        self.bkimg23 = Image.open('bus2.jpg').resize((1350, 700))
        self.bkphotoimg23 = ImageTk.PhotoImage(self.bkimg23)
        self.bklbl = Label(self.window, image=self.bkphotoimg23)
        self.bklbl.place(x=0, y=0)

        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Change Password",font=('Book Antiqua',26,'bold'),
                             background=mycolor2,foreground="black",relief='groove',borderwidth=5)

        self.L1 = Label(self.window,text="Current Password",font=myfont,background=mycolor1)
        self.L2 = Label(self.window,text="New Password",font=myfont,background=mycolor1)
        self.L3 = Label(self.window,text="Confirm Password",font=myfont,background=mycolor1)

        self.t1 = Entry(self.window,font=myfont,show='*')
        self.t2 = Entry(self.window,font=myfont,show='*')
        self.t3 = Entry(self.window,font=myfont,show='*')


        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Change Password",background=mycolor2,
                         foreground="black",font=myfont,command=self.updateData)
        #--------------- placements -----------------------------
        self.headlbl.place(x=0,y=0,width=1350,height=70)
        x1 = 20
        y1 = 100
        x_diff = 200
        y_diff = 40
        self.L1.place(x=x1,y=y1)
        self.t1.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L3.place(x=x1,y=y1)
        self.t3.place(x=x1+x_diff,y=y1)
        y1+=y_diff

        y1+=y_diff
        self.b1.place(x=x1,y=y1,width=190,height=40)


        self.makeDatabaseConnection()
        self.clearPage()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)

    def updateData(self):
        if self.t2.get() != self.t3.get():
            messagebox.showwarning("Failure"," Confirm Password Carefully",parent=self.window)
            return
        try:
            qry = "update usertable set password = %s where username=%s and password = %s"
            rowcount = self.curr.execute(qry ,( self.t2.get(),self.uname,self.t1.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Success"," Change Password Successfully",parent=self.window)
                self.clearPage()
            else:
                messagebox.showwarning("Failure"," Wrong current password",parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ","Error while updating data :\n"+str(e),parent=self.window)

    def clearPage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.t3.delete(0,END)

if __name__ == '__main__':
    dummyHomepage = Tk()
    ChangePasswordClass(dummyHomepage)
    dummyHomepage.mainloop()
