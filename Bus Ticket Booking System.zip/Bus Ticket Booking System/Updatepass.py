from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
import pymysql
class UpdateClass:
    def __init__(self,myframe):
        self.window = myframe

       #--------------------Subframe-------------------
        self.subframe = Frame(self.window, background="red")
        self.subframe.place(x=0, y=0, width=1350, height=700)

        self.bkimg2 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.subframe, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        #----------Personal Deatils----------
        self.headlbl = Label(self.subframe, text="Personal Details", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=650, height=70)

        myfont = ('Book Antiqua', 16)
        mycolor1 = 'white'

        self.L14 = Label(self.subframe, text="ID", font=myfont, background=mycolor1)
        self.L14.place(x=100, y=110, width=180, height=30)
        self.t14 = Entry(self.subframe, font=myfont)
        self.t14.place(x=300, y=110, width=250, height=30)

        self.L1 = Label(self.subframe, text="Name", font=myfont, background=mycolor1)
        self.L1.place(x=100, y=160, width=180, height=30)
        self.t1 = Entry(self.subframe, font=myfont)
        self.t1.place(x=300, y=160, width=250, height=30)

        self.L2 = Label(self.subframe, text="Age", font=myfont, background=mycolor1)
        self.L2.place(x=100, y=210, width=180, height=30)
        self.t2 = Entry(self.subframe, font=myfont)
        self.t2.place(x=300, y=210, width=250, height=30)

        self.L3 = Label(self.subframe, text="Gender", font=myfont, background=mycolor1)
        self.L3.place(x=100, y=260, width=180, height=30)
        self.t3 = Entry(self.subframe, font=myfont)
        self.t3.place(x=300, y=260, width=250, height=30)

        self.L4 = Label(self.subframe, text="Contact Number", font=myfont, background=mycolor1)
        self.L4.place(x=100, y=310, width=180, height=30)
        self.t4 = Entry(self.subframe, font=myfont)
        self.t4.place(x=300, y=310, width=250, height=30)

        self.L5 = Label(self.subframe, text="Email", font=myfont, background=mycolor1)
        self.L5.place(x=100, y=360, width=180, height=30)
        self.t5 = Entry(self.subframe, font=myfont)
        self.t5.place(x=300, y=360, width=250, height=30)

        # ----------Bus Deatils----------
        self.headlbl = Label(self.subframe, text="Bus Details", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=700, y=0, width=650, height=70)

        myfont = ('Book Antiqua', 16)
        mycolor1 = 'white'

        self.L7 = Label(self.subframe, text="Bus Number", font=myfont, background=mycolor1)
        self.L7.place(x=800, y=110, width=180, height=30)
        self.t7 = Entry(self.subframe, font=myfont)
        self.t7.place(x=1000, y=110, width=200, height=30)

        self.L8= Label(self.subframe, text="Bus Name", font=myfont, background=mycolor1)
        self.L8.place(x=800, y=160, width=180, height=30)
        self.t8 = Entry(self.subframe, font=myfont)
        self.t8.place(x=1000, y=160, width=200, height=30)

        self.L9 = Label(self.subframe, text="Bus Type", font=myfont, background=mycolor1)
        self.L9.place(x=800, y=210, width=180, height=30)
        self.t9 = Entry(self.subframe, font=myfont)
        self.t9.place(x=1000, y=210, width=200, height=30)

        self.L10 = Label(self.subframe, text="Route", font=myfont, background=mycolor1)
        self.L10.place(x=800, y=260, width=180, height=30)
        self.t10 = Entry(self.subframe, font=myfont)
        self.t10.place(x=1000, y=260, width=200, height=30)

        self.L11 = Label(self.subframe, text="Date", font=myfont, background=mycolor1)
        self.L11.place(x=800, y=310, width=180, height=30)
        self.t11 = Entry(self.subframe, font=myfont)
        self.t11.place(x=1000, y=310, width=200, height=30)

        self.L13 = Label(self.subframe, text="Arrival/Departure", font=myfont, background=mycolor1)
        self.L13.place(x=800, y=360, width=180, height=30)
        self.t13 = Entry(self.subframe, font=myfont)
        self.t13.place(x=1000, y=360, width=200, height=30)

        self.L15 = Label(self.subframe, text="Price", font=myfont, background=mycolor1)
        self.L15.place(x=800, y=410, width=180, height=30)
        self.t15 = Entry(self.subframe, font=myfont)
        self.t15.place(x=1000, y=410, width=200, height=30)

        self.b2 = Button(self.subframe, text="Fetch Details", background='#7FDDF0', font=('Helvetica', 15) , command=self.fetchData)
        self.b2.place(x=300, y=500, height=35, width=150)
        self.b3 = Button(self.subframe, text="Update Ticket", background='#7FDDF0',font=('Helvetica', 15), state="disabled",command=self.updateData)
        self.b3.place(x=500, y=500, height=35, width=150)
        self.b4 = Button(self.subframe, text="Delete Ticket", font=('Helvetica', 15), background='#7FDDF0', state="disabled", command=self.deleteData)
        self.b4.place(x=700, y=500, height=35, width=150)
        self.b5 = Button(self.subframe, text="Clear Page", font=('Helvetica', 15), background='#7FDDF0',command=self.clearpage)
        self.b5.place(x=900, y=500, height=35, width=150)
        self.t16 = Label(self.window, background='#7FDDF0', font=('Book Antiqua',12))
        self.t16.place(x=300, y=550, width=200, height=50)
        self.b2.bind('<Enter>', lambda e: self.message())
        self.b2.bind('<Leave>', lambda e: self.message1())

        self.makeDatabaseConnection()
        self.clearpage()
        self.window.mainloop()

    def message(self):
        self.t16.config(text='Fetch passenger details by \nentering passenger ID')
    def message1(self):
        self.t16.config(text="")

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost', db='bus', user="root", password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ", "Error database connection :\n" + str(e), parent=self.window)

    def fetchData(self):
        try:
            qry = "select pname,age,gender,cnum,email,bnum,bname,btype,rname,date,arde,price from passengerss where pid like %s"
            rowcount = self.curr.execute(qry,(self.t14.get()))
            data = self.curr.fetchone()
            if data:
                self.t1.insert(0, data[0])
                self.t2.insert(0, data[1])
                self.t3.insert(0, data[2])
                self.t4.insert(0, data[3])
                self.t5.insert(0, data[4])
                self.t7.insert(0, data[5])
                self.t8.insert(0, data[6])
                self.t9.insert(0, data[7])
                self.t10.insert(0, data[8])
                self.t11.insert(0, data[9])
                self.t13.insert(0, data[10])
                self.t15.insert(0, data[11])

                self.b3['state'] = "normal"
                self.b4['state'] = "normal"

            else:
                messagebox.showwarning("Empty ", "No record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while fetching data :\n" + str(e), parent=self.window)
    def updateData(self):
        if self.validate_check2() == False:
            return
        try:
            qry = "update passengerss set pname=%s, age=%s, gender=%s, cnum=%s, email=%s where pid=%s"
            rowcount = self.curr.execute(qry, (self.t1.get(), self.t2.get(),
                                               self.t3.get(), self.t4.get(), self.t5.get(), self.t14.get()))
            self.conn.commit()
            if rowcount == 1:
                messagebox.showinfo("Success", "Passenger Details Updated Successfully", parent=self.window)
                self.clearpage()
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while updating data :\n" + str(e), parent=self.window)

    def deleteData(self):
        ans = messagebox.askquestion("Confirmation", "Are you sure to delete ?", parent=self.window)
        if ans == "yes":
            try:
                qry = "delete from passengerss where pid=%s"
                rowcount = self.curr.execute(qry, (self.t14.get()))
                self.conn.commit()
                if rowcount == 1:
                    messagebox.showinfo("Success", "Bus Details deleted Successfully", parent=self.window)
                    self.clearpage()
            except Exception as e:
                messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def validate_check2(self):
        if len(self.t14.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid passenger ID", parent=self.window)
            return False
        elif len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Enter valid name", parent=self.window)
            return False
        elif not(self.t2.get().isdigit()) or len(self.t2.get())>=3 or len(self.t2.get())<=0:
            messagebox.showwarning("Validation Check", "Enter valid age", parent=self.window)
            return False
        elif not(self.t3.get()== "female" or self.t3.get()== "male" or self.t3.get()== "Male" or self.t3.get()== "Female"):
            messagebox.showwarning("Validation Check", "Enter valid gender", parent=self.window)
            return False
        elif not(self.t4.get().isdigit()) or len(self.t4.get())!=10:
            messagebox.showwarning("Validation Check", "Enter valid phone no \n10 digits only", parent=self.window)
            return False
        elif '.' not in self.t5.get() or '@' not in self.t5.get():
            messagebox.showwarning("Input Error", "Please valid Email Address ", parent=self.window)
            return False
        return True
    def clearpage(self):
        self.t1.delete(0, END)
        self.t2.delete(0, END)
        self.t3.delete(0, END)
        self.t4.delete(0, END)
        self.t5.delete(0, END)
        self.t7.delete(0, END)
        self.t8.delete(0, END)
        self.t9.delete(0, END)
        self.t10.delete(0, END)
        self.t11.delete(0, END)
        self.t13.delete(0, END)
        self.t14.delete(0, END)
        self.t15.delete(0, END)

        self.b3['state'] = "disabled"
        self.b4['state'] = "disabled"

if __name__ == '__main__':
    dummyhomepage = Tk()
    UpdateClass(dummyhomepage)
    dummyhomepage.mainloop()
