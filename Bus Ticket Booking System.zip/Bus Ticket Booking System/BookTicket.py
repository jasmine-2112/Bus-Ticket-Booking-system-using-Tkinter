from tkinter import *
from tkinter.ttk import Combobox, Treeview
from PIL import Image, ImageTk
from tkinter import messagebox
import pymysql
from tkcalendar import DateEntry
import os
from myprintoutPage import my_cust_PDF
class BookTicketClass:
    def __init__(self,myframe):
        self.window = myframe

       #--------------------Subframe-------------------
        self.subframe = Frame(self.window, background="red")
        self.subframe.place(x=0, y=0, width=1350, height=700)

        self.bkimg2 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.subframe, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        #----------Personal Deatils----------
        self.headlbl = Label(self.subframe, text="Personal Details", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=650, height=70)

        myfont = ('Book Antiqua', 16)
        mycolor1 = 'white'

        self.L14 = Label(self.subframe, text="ID", font=myfont, background=mycolor1)
        self.L14.place(x=130, y=110, width=180, height=30)
        self.t14 = Entry(self.subframe, font=myfont)
        self.t14.place(x=330, y=110, width=180, height=30)

        self.L1 = Label(self.subframe, text="Name", font=myfont, background=mycolor1)
        self.L1.place(x=130, y=160, width=180, height=30)
        self.t1 = Entry(self.subframe, font=myfont)
        self.t1.place(x=330, y=160, width=180, height=30)

        self.L2 = Label(self.subframe, text="Age", font=myfont, background=mycolor1)
        self.L2.place(x=130, y=210, width=180, height=30)
        self.t2 = Entry(self.subframe, font=myfont)
        self.t2.place(x=330, y=210, width=180, height=30)

        self.L3 = Label(self.subframe, text="Gender", font=myfont, background=mycolor1)
        self.L3.place(x=130, y=260, width=180, height=30)
        self.t3 = Entry(self.subframe, font=myfont)
        self.t3.place(x=330, y=260, width=180, height=30)

        self.L4 = Label(self.subframe, text="Contact Number", font=myfont, background=mycolor1)
        self.L4.place(x=130, y=310, width=180, height=30)
        self.t4 = Entry(self.subframe, font=myfont)
        self.t4.place(x=330, y=310, width=180, height=30)

        self.L5 = Label(self.subframe, text="Email", font=myfont, background=mycolor1)
        self.L5.place(x=130, y=360, width=180, height=30)
        self.t5 = Entry(self.subframe, font=myfont)
        self.t5.place(x=330, y=360, width=180, height=30)

        # ----------Bus Deatils----------
        self.headlbl = Label(self.subframe, text="Bus Details", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=700, y=0, width=650, height=70)

        myfont = ('Book Antiqua', 16)
        mycolor1 = 'white'

        self.L6 = Label(self.subframe, text="Bus Number", font=myfont, background=mycolor1)
        self.L6.place(x=830, y=110, width=180, height=30)
        self.t6 = Entry(self.subframe, font=myfont)
        self.t6.place(x=1030, y=110, width=180, height=30)

        self.L7 = Label(self.subframe, text="Bus Name", font=myfont, background=mycolor1)
        self.L7.place(x=830, y=160, width=180, height=30)
        self.t7 = Entry(self.subframe, font=myfont)
        self.t7.place(x=1030, y=160, width=180, height=30)

        self.L8= Label(self.subframe, text="Bus Type", font=myfont, background=mycolor1)
        self.L8.place(x=830, y=210, width=180, height=30)
        self.t8 = Entry(self.subframe, font=myfont)
        self.t8.place(x=1030, y=210, width=180, height=30)

        self.L9 = Label(self.subframe, text="Route", font=myfont, background=mycolor1)
        self.L9.place(x=830, y=260, width=180, height=30)
        self.t9 = Entry(self.subframe, font=myfont)
        self.t9.place(x=1030, y=260, width=180, height=30)

        self.L10 = Label(self.subframe, text="Date", font=myfont, background=mycolor1)
        self.L10.place(x=830, y=310, width=180, height=30)
        self.t10 = Entry(self.subframe, font=myfont)
        self.t10.place(x=1030, y=310, width=180, height=30)

        self.L11 = Label(self.subframe, text="Arrival/Departure", font=myfont, background=mycolor1)
        self.L11.place(x=830, y=360, width=180, height=30)
        self.t11 = Entry(self.subframe, font=myfont)
        self.t11.place(x=1030, y=360, width=180, height=30)

        self.L12 = Label(self.subframe, text="Duration", font=myfont, background=mycolor1)
        self.L12.place(x=830, y=410, width=180, height=30)
        self.t12 = Entry(self.subframe, font=myfont)
        self.t12.place(x=1030, y=410, width=180, height=30)

        self.L13 = Label(self.subframe, text="Ticket Price", font=myfont, background=mycolor1)
        self.L13.place(x=830, y=460, width=180, height=30)
        self.t13 = Entry(self.subframe, font=myfont)
        self.t13.place(x=1030, y=460, width=180, height=30)

        self.b2 = Button(self.subframe, text="Save Details",background='#7FDDF0', font=('Helvetica', 15), command=self.saveData)
        self.b2.place(x=900, y=630, height=35, width=150)
        self.b3 = Button(self.subframe, text="Print Ticket",background='#7FDDF0', font=('Helvetica', 15), state="disabled", command=self.print)
        self.b3.place(x=1100, y=630, height=35, width=150)


        # --------------------Main frame-------------------
        self.f1 = Frame(self.subframe, background="pink")
        self.f1.place(x=0, y=0, width=1350, height=700)

        self.bkimg = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg = ImageTk.PhotoImage(self.bkimg)
        self.bklbl = Label(self.f1, image=self.bkphotoimg)
        self.bklbl.place(x=0, y=0)

        self.headlbl = Label(self.f1, text="Book Bus Ticket", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=1350, height=70)

        #--------------------Search Destination Button-------------------
        self.L9 = Label(self.f1, text="Choose Destination",font=20,background=mycolor1)
        self.L9.place(x=450,y=110,width=185,height=40)
        self.v2 = StringVar()
        self.c2 = Combobox(self.f1, values=[""], textvariable=self.v2, state='readonly',)
        self.c2.place(x=670, y=110, width=180, height=40)

        self.L10 = Label(self.f1, text="Choose Date",font=20,background=mycolor1)
        self.L10.place(x=450, y=170)
        self.c3 = DateEntry(self.f1, font=("Calibri", 16), background='blue', year=2023, date_pattern='y-mm-dd')
        self.c3.place(x=670, y=170)

        self.b1 = Button(self.f1, text="Book Ticket",background='#7FDDF0', font=('Helvetica', 15), command=self.show, state='disable')
        self.b1.place(x=600, y=530, height=35, width=150)

        self.b2 = Button(self.f1, text="Search Buses",background='#7FDDF0', font=('Helvetica', 15), command=self.getAllData)
        self.b2.place(x=600, y=220, height=35, width=150)


        # ----------Bus Details Table----------
        self.mytable = Treeview(self.f1, columns=['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7','c8'], height=10)
        self.mytable.heading('c1', text='Bus Number')
        self.mytable.heading('c2', text='Bus Name')
        self.mytable.heading('c3', text='Bus Type')
        self.mytable.heading('c4', text='Route')
        self.mytable.heading('c5', text='Date')
        self.mytable.heading('c6', text='Departure/Arrival')
        self.mytable.heading('c7', text='Duration')
        self.mytable.heading('c8', text='Price')

        self.mytable['show'] = 'headings'

        self.mytable.column('c1', width=150, anchor='center')
        self.mytable.column('c2', width=150, anchor='center')
        self.mytable.column('c3', width=150, anchor='center')
        self.mytable.column('c4', width=150, anchor='center')
        self.mytable.column('c5', width=150, anchor='center')
        self.mytable.column('c6', width=150, anchor='center')
        self.mytable.column('c7', width=150, anchor='center')
        self.mytable.column('c8', width=150, anchor='center')
        self.mytable.place(x=50, y=280)
        self.mytable.bind("<ButtonRelease>", lambda e: self.getSelectedRow())

        self.makeDatabaseConnection()
        self.getAllRoutes()
        self.window.mainloop()

    def show(self):
        self.f1.destroy()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost', db='bus', user="root", password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ", "Error database connection :\n" + str(e), parent=self.window)

    def getAllRoutes(self):
        try:
            qry = "select * from routes"
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.routeList = []
            if data:
                self.c2.set("Select Route")
                for myrow in data:
                    self.routeList.append(myrow)
            else:
                self.c2.set("No Route")
            self.c2.config(values= self.routeList)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)
    def getSelectedRow(self):
        rowid = self.mytable.focus()
        rowitem = self.mytable.item(rowid)
        rowdata = rowitem['values']
        pkcol  = rowdata[0]
        self.fetchData(pkcol)
        messagebox.showinfo("Success","Bus Details has been selected")
    def fetchData(self, pkcolumn=None):
        if pkcolumn==None:
            pk=self.t6.get()
        else:
            pk=pkcolumn
        try:
            qry = "select bnum, bname, btype, rname, date, arde, duration, price from buses where bnum=%s"
            rowcount = self.curr.execute(qry,(pk))
            data = self.curr.fetchone()
            self.clearpage()
            if data:
                self.t6.insert(0, data[0])
                self.t7.insert(0, data[1])
                self.t8.insert(0, data[2])
                self.t9.insert(0, data[3])
                self.t10.insert(0, data[4])
                self.t11.insert(0, data[5])
                self.t12.insert(0, data[6])
                self.t13.insert(0, data[7])

                self.b1['state'] = "normal"

            else:
                messagebox.showwarning("Empty ", "No record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while fetching data :\n" + str(e), parent=self.window)

    def clearpage(self):
        self.t6.delete(0, END)
        self.t7.delete(0, END)
        self.t8.delete(0, END)
        self.t9.delete(0, END)
        self.t10.delete(0, END)
        self.t11.delete(0, END)
        self.t12.delete(0, END)
        self.t13.delete(0, END)
        self.getAllData()

    def getAllData(self):
        if self.validate_check() == False:
            return

        try:
            self.mytable.delete(*self.mytable.get_children())
            des = self.v2.get()
            det = self.c3.get()
            if des == "Select Destination":
                des = ""
            qry = "select bnum, bname, btype, rname, date, arde, duration, price from buses where rname like %s AND date =%s"
            rowcount = self.curr.execute(qry, ((des + '%'), (det + '%')))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("", END, values=myrow)
            else:
                messagebox.showwarning("Empty ", "No record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while fetching data :\n" + str(e), parent=self.window)

    def saveData(self):
        if self.validate_check2() == False:
            return

        try:  # pid	pname	age	gender	cnum	email	bnum	bname	btype	rname	date	arde	price
            qry = "insert into passengerss values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            rowcount = self.curr.execute(qry,
                                         (self.t14.get(), self.t1.get(), self.t2.get(), self.t3.get(), self.t4.get(),
                                          self.t5.get(), self.t6.get(), self.t7.get(), self.t8.get(), self.t9.get(),
                                          self.t10.get(), self.t11.get(), self.t13.get()))
            self.conn.commit()
            if rowcount == 1:
                messagebox.showinfo("Success", "Passenger Details Added Successfully", parent=self.window)
                self.b3['state'] = "normal"
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def validate_check(self):
        if len(self.v2.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid destination name ", parent=self.window)
            return False
        elif len(self.c3.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid date", parent=self.window)
            return False
        return True

    def validate_check2(self):
        if len(self.t14.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid passenger ID", parent=self.window)
            return False
        elif len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Enter valid name", parent=self.window)
            return False
        elif not(self.t2.get().isdigit()) or len(self.t2.get())>=3 or len(self.t2.get())<=0:
            messagebox.showwarning("Validation Check", "Enter valid age", parent=self.window)
            return False
        elif not(self.t3.get()== "female" or self.t3.get()== "male" or self.t3.get()== "Male" or self.t3.get()== "Female"):
            messagebox.showwarning("Validation Check", "Enter valid gender", parent=self.window)
            return False
        elif not(self.t4.get().isdigit()) or len(self.t4.get())!=10:
            messagebox.showwarning("Validation Check", "Enter valid phone no \n10 digits only", parent=self.window)
            return False
        elif '.' not in self.t5.get() or '@' not in self.t5.get():
            messagebox.showwarning("Input Error", "Please valid Email Address ", parent=self.window)
            return False
        return True


    def print(self):
        try:
            des=self.t14.get()
            qry="select pname,gender,bnum,rname,date,arde from passengerss where pid like %s"
            rowcount = self.curr.execute(qry,(des +'%'))
            data = self.curr.fetchall()
            self.pdata=[]
            if data:
                for myrow in data:
                    self.pdata.append(myrow)
                messagebox.showinfo("Success", "Ticket Printed")
            else:
                messagebox.showinfo("Empty", "No record found", parent=self.window)
        except Exception as e:
                messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

        self.print2()

    def print2(self):
        pdf = my_cust_PDF()
        headings=['Name','Gender','Bus number','Route','Date','Arr/Depart']
        pdf.print_chapter(headings,self.pdata)
        pdf.output('pdf_file1.pdf')
        os.system('explorer.exe "pdf_file1.pdf"')


if __name__ == '__main__':
    dummyhomepage = Tk()
    BookTicketClass(dummyhomepage)
    dummyhomepage.mainloop()
