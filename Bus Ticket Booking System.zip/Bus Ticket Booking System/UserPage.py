from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview
import pymysql
from PIL import Image,ImageTk
class UserClass:
    def __init__(self,myframe):
        self.window = myframe

        self.bkimg23 = Image.open('bus2.jpg').resize((1350, 700))
        self.bkphotoimg23 = ImageTk.PhotoImage(self.bkimg23)
        self.bklbl = Label(self.window, image=self.bkphotoimg23)
        self.bklbl.place(x=0, y=0)
        #------------------- widgets -------------------------

        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Manage User",font=('Book Antiqua',26,'bold'),
                             background=mycolor2,foreground="black",relief='groove',borderwidth=5)

        self.L1 = Label(self.window,text="Username",font=myfont,background=mycolor1)
        self.L2 = Label(self.window,text="Password",font=myfont,background=mycolor1)
        self.L3 = Label(self.window,text="Usertype",font=myfont,background=mycolor1)

        self.t1 = Entry(self.window,font=myfont)
        self.t2 = Entry(self.window,font=myfont,show='*')
        self.v1 = StringVar()
        self.c1 = Combobox(self.window,values=['Admin','Employee'], textvariable=self.v1,state='readonly',font=myfont)


        #------------------ table -----------------------------------
        self.mytable =Treeview(self.window,columns=['c1','c2'],height=8)
        self.mytable.heading('c1',text='Username')
        self.mytable.heading('c2',text='Usertype')
        self.mytable['show']='headings'
        self.mytable.column('c1',width=200,anchor='center')
        self.mytable.column('c2',width=200,anchor='center')

        self.mytable.bind("<ButtonRelease>",lambda e : self.getSelectedRow())
        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Save",background=mycolor2,
                         foreground="black",font=myfont,command=self.saveData)
        self.b2 = Button(self.window,text="Update",background=mycolor2,
                         foreground="black",font=myfont,command=self.updateData)
        self.b3 = Button(self.window,text="Delete",background=mycolor2,
                         foreground="black",font=myfont,command=self.deleteData)
        self.b4 = Button(self.window,text="Fetch",background=mycolor2,
                         foreground="black",font=myfont,command=self.fetchData)
        self.b5 = Button(self.window,text="Search",background=mycolor2,
                         foreground="black",font=myfont,command=self.getAllData)


        #--------------- placements -----------------------------
        self.headlbl.place(x=0,y=0,width=1350,height=70)
        x1 = 20
        y1 = 100
        x_diff = 150
        y_diff = 40
        self.L1.place(x=x1,y=y1)
        self.t1.place(x=x1+x_diff,y=y1)
        self.b4.place(x=x1+x_diff*2+100,y=y1,width=120,height=30)
        self.mytable.place(x=x1+x_diff*2+100+160,y=y1)
        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        self.b5.place(x=x1+x_diff*2+100,y=y1,width=120,height=30)
        y1+=y_diff
        self.L3.place(x=x1,y=y1)
        self.c1.place(x=x1+x_diff,y=y1)
        y1+=y_diff

        y1+=y_diff
        self.b1.place(x=x1,y=y1,width=120,height=40)
        self.b2.place(x=x1+x_diff,y=y1,width=120,height=40)
        self.b3.place(x=x1+x_diff*2,y=y1,width=120,height=40)

        self.makeDatabaseConnection()
        self.clearPage()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)


    def saveData(self):
        if self.validate_check()==False:
            return # stop function now
        #save Data
        try:
            qry = "insert into usertable values(%s,%s,%s)"
            rowcount = self.curr.execute(qry , (self.t1.get(),self.t2.get(),self.v1.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Success","User Record Added Successfully",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)


    def updateData(self):
        if self.validate_check()==False:
            return

        try:
            qry = "update usertable set password = %s, usertype=%s where username=%s"
            rowcount = self.curr.execute(qry ,( self.t2.get(),self.v1.get(),self.t1.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Success"," User Record Updated Successfully",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error ","Error while updating data :\n"+str(e),parent=self.window)


    def deleteData(self):
        ans = messagebox.askquestion("Confirmation","Are you sure to delete ?",parent=self.window)
        if ans=="yes":
            try:
                qry = "delete from usertable where username=%s"
                rowcount = self.curr.execute(qry ,(self.t1.get()))
                self.conn.commit()
                if rowcount==1:
                    messagebox.showinfo("Success","user Record Updated Successfully",parent=self.window)
                    self.clearPage()
            except Exception as e:
                messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)

    def getSelectedRow(self):
        rowid = self.mytable.focus()
        rowitem = self.mytable.item(rowid)
        rowdata = rowitem['values']
        pkcol  = rowdata[0]
        self.fetchData(pkcol)

    def fetchData(self,pkcolumn=None):
        if pkcolumn==None:
            un = self.t1.get()
        else:
            un=pkcolumn
        try:
            qry = "select * from usertable where username=%s"
            rowcount = self.curr.execute(qry , (un))
            data = self.curr.fetchone()
            self.clearPage()
            if data:
                self.t1.insert(0,data[0])
                self.t2.insert(0,data[1])
                self.v1.set(data[2])

                self.b2['state'] = "normal"
                self.b3['state'] = "normal"
            else:
                messagebox.showerror("Empty ","No record Found",parent=self.window)
        except Exception as e:
            messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)

    def clearPage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.c1.set("Choose Usertype")
        self.b2['state']="disable"
        self.b3['state']="disable"
        self.getAllData()

    def getAllData(self):
        try:
            self.mytable.delete(*self.mytable.get_children())
            ut = self.v1.get()
            if ut=="Choose Usertype":
                ut=""
            qry = "select * from usertable where usertype like %s"
            rowcount = self.curr.execute(qry,(ut+"%") )
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    r1 = [myrow[0],myrow[2]]
                    self.mytable.insert("",END,values=r1)
            else:
                messagebox.showerror("Empty ","No record Found",parent=self.window)
        except Exception as e:
            messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)


    def validate_check(self):
        if len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Enter user name ", parent=self.window)
            return False
        elif len(self.t2.get())<2:
            messagebox.showwarning("Validation Check", "Enter password ", parent=self.window)
            return False
        elif (self.v1.get() == "Choose Usertype"):
            messagebox.showwarning("Input Error", "Please Select Department ", parent=self.window)
            return False
        return True

if __name__ == '__main__':
    dummyHomepage = Tk()
    UserClass(dummyHomepage)
    dummyHomepage.mainloop()