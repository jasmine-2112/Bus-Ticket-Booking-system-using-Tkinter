from tkinter import *
from tkinter import messagebox
import os
from myprintoutPage import my_cust_PDF
import pymysql
class printClass:
    def __init__(self):
        self.window = Tk()
        self.window.title("Bus Ticket Booking System")
        #------------------- setting -------------------
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        w1 = int(w/3)
        h1 = int(h/3)
        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,int(w1/3),int(h1/3)))

        #------------------- widgets -------------------------

        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Print Bus Ticket ",font=('Book Antiqua',20,'bold'),
                             background=mycolor2,foreground="black",relief='groove',borderwidth=5)
        self.headlbl.place(x=0, y=0, width=w1, height=70)

        self.L1 = Label(self.window,text="Enter Passenger ID to print ticket",font=myfont,background=mycolor1)
        self.L1.place(x=50, y=100)

        self.t1 = Entry(self.window,font=myfont)
        self.t1.place(x=380 , y=100,height=35, width=80)

        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Print",background=mycolor2,
                         foreground="black",font=myfont,command=self.print)
        self.b1.place(x=180, y=160, width=120, height=40)
        #--------------- placements -----------------------------


        self.makeDatabaseConnection()
        self.clearPage()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)


    def print(self):
        try:
            passid=self.t1.get()
            qry="select pname,gender,bnum,rname,date,arde from passengerss where pid=%s"
            rowcount = self.curr.execute(qry,(passid))
            data = self.curr.fetchall()
            self.pdata=[]
            if data:
                for myrow in data:
                    self.pdata.append(myrow)
                    self.print2()
            else:
                messagebox.showinfo("Empty", "No record found", parent=self.window)
        except Exception as e:
                messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def print2(self):
        pdf = my_cust_PDF()
        headings=['Name','Gender','Bus number','Route','Date','Arr/Depart']
        pdf.print_chapter(headings,self.pdata)
        pdf.output('pdf_file1.pdf')
        os.system('explorer.exe "pdf_file1.pdf"')
    def clearPage(self):
        self.t1.delete(0,END)


    def validate_check(self):
        if len(self.t1.get())<1:
            messagebox.showwarning("Validation Check", "Enter Passenger ID ", parent=self.window)
            return False
        return True

if __name__ == '__main__':
   printClass()