-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2023 at 03:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus`
--

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `bnum` varchar(100) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `btype` varchar(100) NOT NULL,
  `rname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `arde` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`bnum`, `bname`, `btype`, `rname`, `date`, `arde`, `duration`, `price`) VALUES
('BV100', 'Volvo', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-20', '00:15-6:45\n', '6h 30min\n', 'Rs. 495'),
('BB100', 'Bharat Benz', 'A/C Seater', 'Jal-amr', '2023-07-20', '08:30-10:10', '1h 40min', 'Rs. 200'),
('BM100', 'Mercedes Benz', 'A/C Seater', 'Jal-amr', '2023-07-20', '08:00-09:30', '1h 30 min', 'Rs. 250\n'),
('BM101', 'Mercedes Benz', 'A/C Seater', 'Jal-Ludh', '2023-07-20', '12:00-13:40', '1h 40min', 'Rs. 175\n'),
('BM102', 'Mercedes Benz', 'A/C Seater', 'Jal-Del', '2023-07-20', '07:30-14:00', '6h 30 min', 'Rs. 550\n'),
('BM103', 'Mercedes Benz', 'A/C Seater', 'Jal-Chan', '2023-07-20', '16:25-18:55', '2h 30min\n', 'Rs. 435'),
('BV101', 'Volvo', 'A/C Seater', 'Jal-Ludh', '2023-07-20', '09:30-11:00', '1h 30 min', 'Rs. 300'),
('BB101', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Chan', '2023-07-20', '23:00-01:30', '2h 30min', 'Rs. 450'),
('BB102', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-20', '21:35-05:30', '7h 55min', 'Rs. 465'),
('BV102', 'Volvo', 'A/C Seater', 'Jal-Chan', '2023-07-20', '06:50-09:00', '2h 10min', 'Rs. 380'),
('BM104', 'Mercedes Benz', 'A/C Seater', 'Jal-amr', '2023-07-21', '16:20-17:50', '1h 30min', 'Rs. 200'),
('BV103', 'Volvo', 'A/C Seater', 'Jal-amr', '2023-07-21', '09:30-11:00', '1h 30min', 'Rs.220'),
('BB103', 'Bharat Benz', 'A/C Seater', 'Jal-amr', '2023-07-21', '10:50-12:30', '1h 40min', 'Rs. 200'),
('BV104', 'Volvo', 'A/C Seater/Sleeper', 'Jal-Chan', '2023-07-21', '16:25-18:55', '2h 30min', 'Rs. 430'),
('BB104', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Chan', '2023-07-21', '23:15-02:30', '3h 15min', 'Rs. 550'),
('BM105', 'Mercedes Benz', 'A/C Seater', 'Jal-Chan', '2023-07-21', '08:40-10:35', '1h 55min', 'Rs. 430'),
('BB105', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-21', '00:40-07:50', '7h 10min', 'Rs. 700'),
('BV105', 'Volvo', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-21', '23:35-06:30', '6h 55min ', 'Rs. 630'),
('BV106', 'Volvo', 'A/C Seater', 'Jal-Ludh', '2023-07-21', '11:15-12:50', '1h 35min', 'Rs. 200'),
('BB106', 'Bharat Benz', 'A/C Seater', 'Jal-Ludh', '2023-07-21', '18:00-19:50', '1h 50min', 'Rs. 250'),
('BV107', 'Volvo', 'A/C Seater', 'Jal-Hosh', '2023-07-20', '09:30-10:40', '1h 20min', 'Rs. 150'),
('BM106', 'Mercedes Benz', 'A/C Seater', 'Jal-Hosh', '2023-07-20', '12:00-13:00', '1h 00min', 'Rs. 200'),
('BM107', 'Mercedes Benz', 'A/C Seater', 'Jal-Hosh', '2023-07-21', '15:10-16:20', '1h 10min', 'Rs. 170'),
('BV108', 'Volvo', 'A/C Seater', 'Jal-Hosh', '2023-07-21', '11:40-12:50', '1h 10min', 'Rs. 210'),
('BM108', 'Mercedes Benz', 'A/C Seater', 'Jal-Del', '2023-07-22', '21:35-05:30', '7h 55min', 'Rs. 514'),
('BB107', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-22', '01:20-07:50', '6h 30min', 'Rs. 475'),
('BV109', 'Volvo', 'A/C Seater', 'Jal-amr', '2023-07-22', '09:30-11:00', '1h 30min', 'Rs. 220'),
('BB108', 'Bharat Benz', 'A/C Seater', 'Jal-amr', '2023-07-22', '05:20-07:05', '1h 45min', 'Rs. 190'),
('BM109', 'Mercedes Benz', 'A/C Seater', 'Jal-Chan', '2023-07-22', '11:40-14:00', '2h 20min', 'Rs. 460'),
('BM110', 'Mercedes Benz', 'A/C Seater', 'Jal-Ludh', '2023-07-22', '11:15-12:50', '1h 35min', 'Rs. 300'),
('BB109', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Ludh', '2023-07-22', '18:00-20:30', '2h 30min', 'Rs. 350'),
('BV110', 'Volvo', 'A/C Seater', 'Jal-Ludh', '2023-07-22', '16:00-18:00', '2h 00min', 'Rs. 275'),
('BB110', 'Bharat Benz', 'A/C Seater', 'Jal-Hosh', '2023-07-22', '07:30-8:40', '1h 10min', 'Rs. 150'),
('BB111', 'Bharat Benz', 'A/C Seater', 'Jal-Hosh', '2023-07-22', '10:00-11:30', '1h 30min', 'Rs. 210'),
('BV111', 'Volvo', 'A/C Seater', 'Jal-Hosh', '2023-07-22', '14:10-15:30', '1h 20min', 'Rs.200'),
('BM111', 'Mercedes Benz', 'A/C  Seater', 'Jal-Hosh', '2023-07-22', '19:00-20:20', '1h 20min', 'Rs.180');

-- --------------------------------------------------------

--
-- Table structure for table `passengerss`
--

CREATE TABLE `passengerss` (
  `pid` varchar(100) NOT NULL,
  `pname` text NOT NULL,
  `age` int(11) NOT NULL,
  `gender` text NOT NULL,
  `cnum` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `bnum` varchar(100) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `btype` varchar(100) NOT NULL,
  `rname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `arde` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passengerss`
--

INSERT INTO `passengerss` (`pid`, `pname`, `age`, `gender`, `cnum`, `email`, `bnum`, `bname`, `btype`, `rname`, `date`, `arde`, `price`) VALUES
('P100', 'Jasmine', 21, 'female', '9855789868', 'jasmine123@gmail.com', 'BV100', 'Volvo', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-20', '00:15-6:45\n', 'Rs. 495'),
('P101', 'Rohit', 25, 'male', '9874563210', 'rohit123@gmai.com', 'BM100', 'Mercedes Benz', 'A/C Seater', 'Jal-amr', '2023-07-20', '08:00-09:30', 'Rs. 250\n'),
('P103', 'Khushi', 30, 'Female', '9182736450', 'khushiarora1234@gmail.com', 'BM100', 'Mercedes Benz', 'A/C Seater', 'Jal-amr', '2023-07-20', '08:00-09:30', 'Rs. 250\n'),
('P109', 'Ram', 28, 'Male', '9871122600', 'ramsharma123@gmail.com', 'BM102', 'Mercedes Benz', 'A/C Seater', 'Jal-Del', '2023-07-20', '07:30-14:00', 'Rs. 550\n'),
('P110', 'Payal', 30, 'Female', '8877665544', 'payalsharma987@gmail.com', 'BB102', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-20', '21:35-05:30', 'Rs. 465'),
('P115', 'Manpreet Kaur', 36, 'Female', '9800001234', 'manpreetkaur122@gmail.com', 'BB107', 'Bharat Benz', 'A/C Seater/Sleeper', 'Jal-Del', '2023-07-22', '6h 30min', 'Rs. 475'),
('P117', 'Tanvi', 46, 'Female', '9183746500', 'tanvikapoor12@gmail.com', 'BV101', 'Volvo', 'A/C Seater', 'Jal-Ludh', '2023-07-20', '09:30-11:00', 'Rs. 300');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `rname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`rname`) VALUES
('Jal-amr'),
('Jal-Del'),
('Jal-Hosh'),
('Jal-Ludh'),
('Jal-Chan');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`username`, `password`, `usertype`) VALUES
('admin', '123', 'Admin'),
('user', 'user', 'Employee'),
('admin2', '123', 'Admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
