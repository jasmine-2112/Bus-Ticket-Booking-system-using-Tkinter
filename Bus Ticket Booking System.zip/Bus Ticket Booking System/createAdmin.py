from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox
import pymysql
class CreateAdminClass:
    def __init__(self):
        self.window = Tk()
        self.window.title("Bus Ticket Booking System")
        #------------------- setting -------------------
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        w1 = int(w/2)
        h1 = int(h/2)
        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,int(w1/2),int(h1/2)))   # width,height,x,y

        #------------------- widgets -------------------------

        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Welcome to Jalandhar Bus Ticket Booking System",font=('Book Antiqua',20,'bold'),
                             background=mycolor2,foreground="black",relief='groove',borderwidth=5)

        self.L1 = Label(self.window,text="Username",font=myfont,background=mycolor1)
        self.L2 = Label(self.window,text="Password",font=myfont,background=mycolor1)
        self.L3 = Label(self.window,text="Usertype",font=myfont,background=mycolor1)

        self.t1 = Entry(self.window,font=myfont)
        self.t2 = Entry(self.window,font=myfont,show='*')
        self.v1 = StringVar()
        self.c1 = Combobox(self.window,values=['Admin','Employee'],
                           textvariable=self.v1,state='disable',font=myfont)
        self.c1.current(0)

        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Create Admin",background=mycolor2,
                         foreground="black",font=myfont,command=self.saveData)

        #--------------- placements -----------------------------
        self.headlbl.place(x=0,y=0,width=w1,height=70)
        x1 = 200
        y1 = 100
        x_diff = 150
        y_diff = 40
        self.L1.place(x=x1,y=y1)
        self.t1.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L3.place(x=x1,y=y1)
        self.c1.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        y1+=y_diff
        self.b1.place(x=x1,y=y1,width=370,height=40)

        self.makeDatabaseConnection()
        self.clearPage()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)
    def saveData(self):
        if self.validate_check()==False:
            return # stop function now
        #save Data
        try:
            qry = "insert into usertable values(%s,%s,%s)"
            rowcount = self.curr.execute(qry , (self.t1.get(),self.t2.get(),self.v1.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Success","Admin created Successfully",parent=self.window)
                self.clearPage()
                self.window.destroy()
                from loginpage import LoginClass
                LoginClass()
        except Exception as e:
            messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)

    def clearPage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)

    def validate_check(self):
        if len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Enter user name ", parent=self.window)
            return False
        elif len(self.t2.get())<2:
            messagebox.showwarning("Validation Check", "Enter password ", parent=self.window)
            return False
        elif (self.v1.get() == "Choose Usertype"):
            messagebox.showwarning("Input Error", "Please Select Usertype ", parent=self.window)
            return False
        return True

if __name__ == '__main__':
    CreateAdminClass()