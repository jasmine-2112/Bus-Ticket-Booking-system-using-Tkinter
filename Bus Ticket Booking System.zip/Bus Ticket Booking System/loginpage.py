from tkinter import *
from tkinter import messagebox
import pymysql
class LoginClass:
    def __init__(self):
        self.window = Tk()
        self.window.title("Bus Ticket Booking System")
        #------------------- setting -------------------
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        w1 = int(w/2)
        h1 = int(h/2)
        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,int(w1/2),int(h1/2)))

        #------------------- widgets -------------------------

        myfont=('Book Antiqua',16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window,text="Welcome to Jalandhar Bus Ticket Booking System",font=('Book Antiqua',20,'bold'),
                             background=mycolor2,foreground="black",relief='groove',borderwidth=5)

        self.L1 = Label(self.window,text="Username",font=myfont,background=mycolor1)
        self.L2 = Label(self.window,text="Password",font=myfont,background=mycolor1)

        self.t1 = Entry(self.window,font=myfont)
        self.t2 = Entry(self.window,font=myfont,show='*')

        #--------------- buttons ---------------------------
        self.b1 = Button(self.window,text="Login",background=mycolor2,
                         foreground="black",font=myfont,command=self.checkData)
        #--------------- placements -----------------------------
        self.headlbl.place(x=0,y=0,width=w1,height=70)
        x1 = 200
        y1 = 100
        x_diff = 150
        y_diff = 40
        self.L1.place(x=x1,y=y1)
        self.t1.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.b1.place(x=x1+100,y=y1+30,width=120,height=40)

        self.makeDatabaseConnection()
        self.clearPage()
        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost',db='bus',user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ","Error database connection :\n"+str(e),parent=self.window)

    def checkData(self):
        try:
            qry = "select * from usertable where username=%s  and password =%s"
            rowcount = self.curr.execute(qry ,(self.t1.get() , self.t2.get()))
            data = self.curr.fetchone()
            self.clearPage()
            if data:
                uname = data[0]
                utype = data[2]

                self.window.destroy()
                from Homepage import homepage
                homepage(uname,utype)
            else:
                messagebox.showerror("Empty ","Wrong username or password",parent=self.window)


        except Exception as e:
            messagebox.showerror("Query Error ","Error while saving data :\n"+str(e),parent=self.window)
    def clearPage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)

    def validate_check(self):
        if len(self.t1.get())<2:
            messagebox.showwarning("Validation Check", "Enter user name ", parent=self.window)
            return False
        elif len(self.t2.get())<2:
            messagebox.showwarning("Validation Check", "Enter password ", parent=self.window)
            return False
        return True

if __name__ == '__main__':
   LoginClass()