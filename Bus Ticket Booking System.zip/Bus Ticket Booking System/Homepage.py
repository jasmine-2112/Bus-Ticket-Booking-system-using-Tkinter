from tkinter import *
from Home import HomeClass
from BookTicket import BookTicketClass
from ManagePass import ManangePassengersClass
from ManageRoutes import ManageRoutesClass
from ManageBuses import ManageBusesClass
from busdetails import BusDetailsClass
from UserPage import UserClass
from ChangePasswordPage  import ChangePasswordClass

from tkinter import messagebox

class homepage:
    def __init__(self,uname,utype):
        self.uname = uname
        self.utype = utype


        self.window = Tk()
        self.window.title("Bus Ticket booking system")
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        w1 = int(w / 2)
        h1 = int(h / 2)
        self.window.minsize(w1, h1)
        self.window.geometry("%dx%d+%d+%d" % (w1, h1, int(w1 / 2), int(h1 / 2)))
        self.window.state('zoomed')

        # -------------Frame 1-------------------
        self.f1 = Frame(self.window, background="#F6F681")
        self.f1.place(x=0, y=100, width=250, height=700)
        self.b1 = Button(self.f1, text="Home", font=('Helvetica', 15) , command=self.home)
        self.b1.place(x=15, y=100, height=40, width=190)
        self.b2 = Button(self.f1, text="Book Bus Ticket", font=('Helvetica', 15),command=self.show4)
        self.b2.place(x=15, y=160, height=40, width=190)
        self.b3 = Button(self.f1, text="Manage Passengers", font=('Helvetica', 15) , command=self.show2)
        self.b3.place(x=15, y=220, height=40, width=190)
        self.b4 = Button(self.f1, text="Manage Routes", font=('Helvetica', 15), command=self.show5)
        self.b4.place(x=15, y=280, height=40, width=190)
        self.b5 = Button(self.f1, text="Manage Buses", font=('Helvetica', 15), command=self.show3)
        self.b5.place(x=15, y=340, height=40, width=190)
        self.b6 = Button(self.f1, text="Bus Details", font=('Helvetica', 15), command=self.show1)
        self.b6.place(x=15, y=400, height=40, width=190)
        self.b7 = Button(self.f1, text="Manage User", font=('Helvetica', 15), command=self.show6)
        self.b7.place(x=15, y=460, height=40, width=190)
        self.b8 = Button(self.f1, text="Logout", font=('Helvetica', 15), command=self.quitter)
        self.b8.place(x=15, y=520, height=40, width=190)

        # ---------------Frame 2------------------
        self.f2 = Frame(self.window, background="#F6F681")
        self.f2.place(x=0, y=0, width=1600, height=100)
        self.L2 = Label(self.f2, text="JALANDHAR BUS TICKET BOOKING SYSTEM", background="#F6F681", font=('Times New Roman', 40))
        self.L2.place(x=200, y=20)

        # ------------Frame 3------------------------
        self.f3 = Frame(self.window)
        self.f3.place(x=220, y=100, width=1350, height=700)

        from PIL import Image, ImageTk
        self.bkimg2 = Image.open("bus.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.f3, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        if (self.utype == "Employee"):
            self.b4['state'] = "disable"
            self.b5['state'] = "disable"
            self.b7['state'] = "disable"
            self.b7.destroy()
            self.b9 = Button(self.f1, text="Change Password", font=('Helvetica', 15), command=self.show7)
            self.b9.place(x=15, y=460, height=40, width=190)

        self.window.mainloop()

    def home(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        HomeClass(self.f3)
    def show1(self):
        self.f3.destroy()
        self.f3 = Frame(self.window,background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        BusDetailsClass(self.f3)

    def show2(self):
        self.f3.destroy()
        self.f3 = Frame(self.window,background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        ManangePassengersClass(self.f3)

    def show3(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        ManageBusesClass(self.f3)

    def show4(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        BookTicketClass(self.f3)

    def show5(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        ManageRoutesClass(self.f3)

    def show6(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        UserClass(self.f3)

    def show7(self):
        self.f3.destroy()
        self.f3 = Frame(self.window, background="red")
        self.f3.place(x=220, y=100, width=1350, height=700)
        ChangePasswordClass(self.f3,self.uname)

    def quitter(self):
        ans = messagebox.askquestion("Confirmation", "Are you sure to Logout ?", parent=self.window)
        if ans == "yes":
            self.window.destroy()

if __name__ == '__main__':
    homepage("admin","123")

