from tkinter import *
from PIL import Image, ImageTk
class HomeClass:
    def __init__(self,myframe):
        self.window = myframe
        self.f1 = Frame(self.window)
        self.f1.place(x=0, y=0, width=1350, height=700)

       #--------------------Image-------------------
        self.bkimg2 = Image.open("bus.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.f1, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        self.window.mainloop()

if __name__ == '__main__':
    dummyhomepage = Tk()
    HomeClass(dummyhomepage)
    dummyhomepage.mainloop()
