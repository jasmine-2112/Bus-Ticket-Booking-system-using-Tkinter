from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview
import pymysql


class ManageRoutesClass:
    def __init__(self, myframe):
        self.window = myframe
        # ----------Background Image----------
        from PIL import Image, ImageTk
        self.bkimg2 = Image.open("bus2.jpg").resize((1350, 700))
        self.bkphotoimg2 = ImageTk.PhotoImage(self.bkimg2)
        self.bklbl = Label(self.window, image=self.bkphotoimg2)
        self.bklbl.place(x=0, y=0)

        myfont = ('Book Antiqua', 16)
        mycolor1 = 'white'
        mycolor2 = '#7FDDF0'
        self.window.config(background=mycolor1)
        self.headlbl = Label(self.window, text="Manage Routes", font=('Book Antiqua', 26, 'bold'),
                             background="#7FDDF0", relief='groove', borderwidth=5)
        self.headlbl.place(x=0, y=0, width=1320, height=70)

        self.L1 = Label(self.window, text="Route", font=20, background=mycolor1)
        self.L1.place(x=230, y=170, width=180, height=40)
        self.t1 = Entry(self.window, font=myfont)
        self.t1.place(x=430, y=170, width=180, height=40)

        # --------------- buttons ---------------------------
        self.b1 = Button(self.window, text="Save Route", background=mycolor2, font=myfont, command=self.saveData)
        self.b1.place(x=230, y=250, width=160, height=40)
        self.b2 = Button(self.window, text="Search", background=mycolor2, font=myfont, command=self.getAllData)
        self.b2.place(x=650, y=170, width=130, height=40)
        self.b3 = Button(self.window, text="Delete", background=mycolor2, font=myfont, command=self.deleteData)
        self.b3.place(x=650, y=250, width=130, height=40)
        self.b4 = Button(self.window, text="Clear Page", background=mycolor2, font=myfont, command=self.clearPage)
        self.b4.place(x=450, y=250, width=160, height=40)

        # -------------Table-------------------
        self.mytable = Treeview(self.window, columns=['c1'], height=10 )
        self.mytable.heading('c1', text="Route")

        self.mytable['show'] = 'headings'

        self.mytable.column('c1', width=180, anchor='center')
        self.mytable.place(x=870, y=130)
        self.mytable.bind("<ButtonRelease>", lambda e: self.getSelectedRow())

        self.makeDatabaseConnection()
        self.clearPage()

        self.window.mainloop()

    def makeDatabaseConnection(self):
        try:
            self.conn = pymysql.connect(host='localhost', db='bus', user="root", password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Database Error ", "Error database connection :\n" + str(e), parent=self.window)

    def saveData(self):
        if self.validate_check() == False:
            return  # stop function now
        # save Data
        try:
            qry = "insert into routes values(%s)"
            rowcount = self.curr.execute(qry, (self.t1.get()))
            self.conn.commit()
            if rowcount == 1:
                messagebox.showinfo("Success", "Destination Record Added Successfully", parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def deleteData(self):
        ans = messagebox.askquestion("Confirmation", "Are you sure to delete ?", parent=self.window)
        if ans == "yes":
            try:
                qry = "delete from routes where rname=%s"
                rowcount = self.curr.execute(qry, (self.t1.get()))
                self.conn.commit()
                if rowcount == 1:
                    messagebox.showinfo("Success", "Destination Record Deleted Successfully", parent=self.window)
                    self.clearPage()
            except Exception as e:
                messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def getSelectedRow(self):
        rowid = self.mytable.focus()
        rowitem = self.mytable.item(rowid)
        rowdata = rowitem['values']
        pkcol = rowdata[0]
        self.fetchData(pkcol)

    def fetchData(self, pkcolumn=None):
        if pkcolumn == None:
            des = self.t1.get()
        else:
            des = pkcolumn
        try:
            qry = "select * from routes where rname=%s"
            rowcount = self.curr.execute(qry, (des))
            data = self.curr.fetchone()
            self.clearPage()
            if data:
                self.t1.insert(0, data[0])
                self.b3['state'] = "normal"
            else:
                messagebox.showerror("Empty ", "No record Found", parent=self.window)
        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def clearPage(self):
        self.t1.delete(0, END)
        self.b3['state'] = "disable"
        self.getAllData()

    def getAllData(self):
        try:
            self.mytable.delete(*self.mytable.get_children())
            qry = "select * from routes where rname like %s"
            rowcount = self.curr.execute(qry, (self.t1.get() + "%"))
            data = self.curr.fetchall()
            if data:
                for myrow in data:
                    self.mytable.insert("", END, values=myrow)
            else:
                messagebox.showerror("Empty ", "No record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error ", "Error while saving data :\n" + str(e), parent=self.window)

    def validate_check(self):
        if len(self.t1.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter Destination name ", parent=self.window)
            return False
        return True


if __name__ == '__main__':
    dummyHomepage = Tk()
    ManageRoutesClass(dummyHomepage)
    dummyHomepage.mainloop()
